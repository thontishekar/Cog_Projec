﻿using Microsoft.AspNetCore.Mvc;

using IPMS_Final.Models;

using IPMS_Final.Services;

using System.Diagnostics;

namespace IPMS_Final_MVC.Controllers

{

    public class PerformanceController : Controller

    {

        private readonly PerformanceServices _performanceServices;

        public PerformanceController(PerformanceServices performanceServices)

        {

            _performanceServices = performanceServices;

        }

        // GET: Performance/Index

        public IActionResult Index()

        {

            var performanceList = _performanceServices.GetAllPerformance();

            return View(performanceList);

        }

        // GET: Performance/Edit/{id}

        public IActionResult Edit(int id)

        {

            var performance = _performanceServices.SearchPerformance(id);

            if (performance == null)

            {

                return NotFound();

            }

            return View(performance);

        }

        // POST: Performance/Edit

        [HttpPost]

        [ValidateAntiForgeryToken]

        public IActionResult Edit(Performance performance)

        {

            Debug.WriteLine($"Received Edit request for ID: {performance.PerformanceId}");

            if (ModelState.IsValid)

            {

                bool result = _performanceServices.UpdatePerformance(performance);

                if (result)

                {

                    TempData["SuccessMessage"] = "Performance record updated successfully!";

                    return RedirectToAction(nameof(Index));

                }

                else

                {

                    ModelState.AddModelError("", "Error updating the record.");

                }

            }

            Debug.WriteLine($"Model State Errors: {string.Join(", ", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage))}");

            // Fetch latest data before redisplaying form

            var updatedPerformance = _performanceServices.SearchPerformance(performance.PerformanceId);

            return View(updatedPerformance ?? performance);

        }

        // POST: Performance/Delete/{id}

        [HttpPost]

        [ValidateAntiForgeryToken]

        public IActionResult Delete(int id)

        {

            var performance = _performanceServices.SearchPerformance(id);

            if (performance == null)

            {

                return NotFound();

            }

            bool result = _performanceServices.RemovePerformance(performance);

            if (result)

            {

                TempData["SuccessMessage"] = "Performance record deleted successfully!";

                return RedirectToAction(nameof(Index));

            }

            else

            {

                TempData["ErrorMessage"] = "Error deleting performance record.";

                return RedirectToAction(nameof(Index));

            }

        }

        // GET: Performance/Create

        public IActionResult Create()

        {

            var assets = _performanceServices.GetAllAssets();

            ViewBag.Assets = assets ?? new List<Asset>(); // Ensure ViewBag.Assets is always a valid list

            return View();

        }


        // POST: Performance/Create

        [HttpPost]

        [ValidateAntiForgeryToken]

        public IActionResult Create(Performance performance)

        {

            if (ModelState.IsValid)

            {

                _performanceServices.AddPerformance(performance);

                TempData["SuccessMessage"] = "Performance record added successfully!";

                return RedirectToAction(nameof(Index));

            }

            ModelState.AddModelError("", "Error adding performance record.");

            return View(performance);

        }


        public IActionResult AnalyticsDashboard()

        {

            var performanceData = _performanceServices.GetAllPerformance();

            return View(performanceData);

        }

        [HttpGet]

        public JsonResult GetPurchasePrice(int assetId)

        {

            var asset = _performanceServices.GetAssetById(assetId);

            return Json(new { purchasePrice = asset?.PurchasePrice ?? 0 });

        }





    }

}

