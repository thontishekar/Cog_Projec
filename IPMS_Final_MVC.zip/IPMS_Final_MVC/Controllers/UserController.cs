﻿using IPMS_Final.Models;
using IPMS_Final.Services;
using Microsoft.AspNetCore.Mvc;

namespace IPMS_Final_MVC.Controllers
{
    public class UserController : Controller

    {

        private readonly UserService _userService;

        public UserController(UserService userService)

        {

            _userService = userService;

        }

        public IActionResult RegisterUser()

        {

            return View("Register");

        }

        [HttpPost]

        public async Task<IActionResult> RegisterUser(User user)

        {

            if (ModelState.IsValid)

            {

                var existingUser = await _userService.GetUserByEmailAsync(user.Email);

                if (existingUser != null)

                {

                    ModelState.AddModelError("Email", "Email address is already in use.");

                    return View("Register", user);

                }

                await _userService.RegisterUserAsync(user);

                return RedirectToAction("LoginUser");

            }

            return View("Register", user);

        }

        public IActionResult LoginUser()

        {

            return View("Login");

        }

        [HttpPost]

        public async Task<IActionResult> LoginUser(string email, string password)

        {

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))

            {

                ViewBag.ErrorMessage = "Please enter both email and password.";

                return View("Login");

            }

            var user = await _userService.AuthenticateUserAsync(email, password);

            if (user != null)

            {

                HttpContext.Session.SetInt32("UserId", user.UserId);

                HttpContext.Session.SetString("UserRole", user.Role.ToString());

                // Redirect to the Home/Index page after successful login

                return RedirectToAction("Dashboard", "User");

            }

            else

            {

                ViewBag.ErrorMessage = "Invalid email or password.";

                return View("Login");

            }

        }

        public async Task<IActionResult> UpdateUserProfile(int userId)

        {

            var user = await _userService.GetUserByEmailAsync(User.Identity.Name);

            if (user == null)

            {

                return NotFound();

            }

            return View("UpdateUserProfile", user);

        }

        public async Task<IActionResult> Dashboard()

        {

            return View();

        }

        [HttpPost]

        public async Task<IActionResult> UpdateUserProfile(User updatedUser)

        {

            if (ModelState.IsValid)

            {

                var result = await _userService.UpdateUserProfileAsync(updatedUser);

                if (result != null)

                {

                    return RedirectToAction("Index", "Home");

                }

                else

                {

                    return NotFound();

                }

            }

            return View("UpdateProfile", updatedUser);

        }

    }

}
