﻿using IPMS_Final.Models;
using IPMS_Final.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using IPMS_Final.Data;
using System;
using System.Threading.Tasks; // For async operations
using System.Linq; // For LINQ operations

namespace IPMS_Final_MVC.Controllers
{
    public class ReportController : Controller
    {
        private readonly ReportService _reportService;
        private readonly PortfolioDBContext _context;

        public ReportController(ReportService reportService, PortfolioDBContext context)
        {
            _reportService = reportService;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GeneratePortfolioReport(int portfolioId)
        {
            try
            {
                // Fetch data asynchronously
                var portfolio = await _context.Ports.FirstOrDefaultAsync(p => p.PortfolioId == portfolioId);
                var assets = await _context.Assets.Where(a => a.PortfolioId == portfolioId).ToListAsync();

                if (portfolio == null)
                {
                    return NotFound("Portfolio not found.");
                }

                var reportData = new
                {
                    Portfolio = portfolio,
                    Assets = assets,
                    TotalValue = assets.Sum(a => a.Quantity * a.PurchasePrice)
                };

                // Store the generated report in the database
                await StoreReportAsync("Portfolio", DateTime.Now);

                return View("GeneratePortfolioReport", reportData);
            }
            catch (Exception ex)
            {
                // Log the exception (you might want to use a logging framework)
                Console.Error.WriteLine(ex);
                return View("Error", ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> GenerateAssetReport(int portfolioId)
        {
            try
            {
                // Fetch data asynchronously
                var assets = await _context.Assets.Where(a => a.PortfolioId == portfolioId).ToListAsync();

                if (assets == null || assets.Count == 0)
                {
                    return NotFound("No assets found for this portfolio.");
                }

                // Store the generated report
                await StoreReportAsync("Asset", DateTime.Now);

                return View("GenerateAssetReport", assets); // Ensure view name matches
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.Error.WriteLine(ex);
                return View("Error", ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> GenerateRiskReport(int portfolioId)
        {
            try
            {
                // Fetch data asynchronously
                var risk = await _context.Risks.FirstOrDefaultAsync(r => r.PortfolioId == portfolioId);

                if (risk == null)
                {
                    return NotFound("Risk analysis not found for this portfolio.");
                }

                // Store the generated report
                await StoreReportAsync("Risk", DateTime.Now);

                return View("GenerateRiskReport", risk); // Pass risk data to the view
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.Error.WriteLine(ex);
                return View("Error", ex.Message);
            }
        }

        private async Task StoreReportAsync(string reportType, DateTime generatedDate)
        {
            var report = new Report
            {
                reportType = (ReportType)Enum.Parse(typeof(ReportType), reportType),
                generatedDate = DateOnly.FromDateTime(generatedDate)
            };

            _context.Reports.Add(report);
            await _context.SaveChangesAsync();
        }

        // GET: Reports/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Reports == null)
            {
                return NotFound();
            }

            var report = await _context.Reports.FirstOrDefaultAsync(m => m.reportId == id);
            if (report == null)
            {
                return NotFound();
            }

            return View(report);
        }

        // POST: Reports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Reports == null)
            {
                return Problem("Entity set 'PortfolioDBContext.Reports'  is null.");
            }
            var report = await _context.Reports.FindAsync(id);
            if (report != null)
            {
                _context.Reports.Remove(report);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Error(string message)
        {
            return View("Error", message);
        }
    }
}