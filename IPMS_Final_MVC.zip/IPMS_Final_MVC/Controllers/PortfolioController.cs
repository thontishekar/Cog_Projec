﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using IPMS_Final.Services;
using System.Globalization;
using IPMS_Final.Data;
using IPMS_Final.Models;

namespace IPMS_MVC.Controllers
{
    public class PortfolioController : Controller

    {

        private readonly Portservices _portfolioServices;

        private readonly PortfolioDBContext _context;



        public PortfolioController(PortfolioDBContext context, Portservices portfolioServices)

        {

            _context = context;

            _portfolioServices = portfolioServices;

        }



        // GET: Portfolio 

        public async Task<IActionResult> Index()

        {

            var portfolios = await _portfolioServices.GetAllPortsAsync();

            return View(portfolios);

        }



        // GET: Portfolio/Details/5 

        public async Task<IActionResult> Details(int? id)

        {

            var portfolio = await _portfolioServices.GetPortfolioByIdAsync(id);

            if (portfolio == null)

            {

                return NotFound();

            }

            return View(portfolio);

        }



        // GET: Portfolio/Create 

        public IActionResult Create()

        {

            ViewData["UserId"] = new SelectList(_context.Users_s, "UserId", "Username");

            return View();

        }



        // POST: Portfolio/Create 

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("UserId,PortfolioName")] Portfolio portfolio)
        {
            portfolio.CreationDate = DateTime.UtcNow;

            if (await _portfolioServices.AddPortfolioAsync(portfolio))
            {
                return RedirectToAction("AddAsset", new { id = portfolio.PortfolioId });
            }
            else
            {
                ModelState.AddModelError("", "Failed to create portfolio.");
            }

            ViewData["UserId"] = new SelectList(_context.Users_s, "UserId", "Username", portfolio.UserId);
            return View(portfolio);
        }


        // GET: Portfolio/Edit/5 

        public async Task<IActionResult> Edit(int? id)

        {

            var portfolio = await _portfolioServices.GetPortfolioByIdAsync(id);

            if (portfolio == null)

            {

                return NotFound();

            }

            ViewData["UserId"] = new SelectList(_context.Users_s, "UserId", "Username", portfolio.UserId);

            return View(portfolio);

        }



        // POST: Portfolio/Edit/5 

        [HttpPost]

        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Edit(int id, [Bind("PortfolioId,UserId,PortfolioName,CreationDate")] Portfolio portfolio)

        {

            if (id != portfolio.PortfolioId)

            {

                return NotFound();

            }



            ModelState.Remove("Users_s");

            ModelState.Remove("Risks");

            ModelState.Remove("Assets");



            if (ModelState.IsValid)

            {

                if (await _portfolioServices.UpdatePortfolioAsync(portfolio))

                {

                    return RedirectToAction(nameof(Index));

                }

                else

                {

                    ModelState.AddModelError("", "Failed to update portfolio.");

                }

            }

            ViewData["UserId"] = new SelectList(_context.Users_s, "UserId", "Username", portfolio.UserId);

            return View(portfolio);

        }



        // GET: Portfolio/Delete/5 

        public async Task<IActionResult> Delete(int? id)

        {

            var portfolio = await _portfolioServices.GetPortfolioByIdAsync(id);

            if (portfolio == null)

            {

                return NotFound();

            }

            return View(portfolio);

        }



        // POST: Portfolio/Delete/5 

        [HttpPost, ActionName("Delete")]

        [ValidateAntiForgeryToken]

        public async Task<IActionResult> DeleteConfirmed(int id)

        {

            if (await _portfolioServices.DeletePortfolioAsync(id))

            {

                return RedirectToAction(nameof(Index));

            }

            else

            {

                return NotFound();

            }

        }



        // GET: Portfolio/AddAsset/5 

        public IActionResult AddAsset(int id)

        {

            ViewBag.PortfolioId = id;

            return View();

        }



        // POST: Portfolio/AddAsset 

        [HttpPost]

        [ValidateAntiForgeryToken]

        public async Task<IActionResult> AddAsset(IFormCollection form)

        {

            int portfolioId;

            AssetType assetType;

            if (!int.TryParse(form["PortfolioId"], out portfolioId))

            {

                ModelState.AddModelError("PortfolioId", "Invalid PortfolioId");

                return View();

            }



            if (await _portfolioServices.GetPortfolioByIdAsync(portfolioId) == null)

            {

                ModelState.AddModelError("PortfolioId", "Invalid PortfolioId");

                return View();

            }



            if (string.IsNullOrEmpty(form["AssetName"]) || string.IsNullOrEmpty(form["AssetType"]) ||

                string.IsNullOrEmpty(form["Quantity"]) || string.IsNullOrEmpty(form["PurchasePrice"]))

            {

                ModelState.AddModelError("", "All fields are required.");

                return View();

            }



            if (!Enum.TryParse(form["AssetType"], out assetType))

            {

                ModelState.AddModelError("AssetType", "Invalid AssetType");

                return View();

            }



            try

            {

                Asset asset = new Asset

                {

                    PortfolioId = portfolioId,

                    AssetName = form["AssetName"],

                    AssetType = assetType,

                    Quantity = int.Parse(form["Quantity"]),

                    PurchasePrice = decimal.Parse(form["PurchasePrice"])

                };



                if (await _portfolioServices.AddAssetToPortfolioAsync(asset))

                {

                    return RedirectToAction("Details", new { id = asset.PortfolioId });

                }

                else

                {

                    ModelState.AddModelError("", "An error occurred while adding the asset. Please try again.");

                }

            }

            catch (Exception ex)

            {

                Console.WriteLine($"Error adding asset: {ex.Message}");

                ModelState.AddModelError("", "An error occurred while adding the asset. Please try again.");

            }

            return View();

        }



        // GET: Portfolio/EditAsset/5 

        [Route("Portfolio/EditAsset/{id}")]

        public async Task<IActionResult> EditAsset(int? id)

        {

            var asset = await _portfolioServices.GetAssetByIdAsync(id);

            if (asset == null)

            {

                return NotFound();

            }

            return View(asset);

        }



        // POST: Portfolio/EditAsset/5 

        [HttpPost]

        [ValidateAntiForgeryToken]

        [Route("Portfolio/EditAsset/{id}")]

        public async Task<IActionResult> EditAsset(int id, Asset asset, string Quantity, string PurchasePrice)

        {

            if (id != asset.AssetId)

            {

                return NotFound();

            }



            try

            {

                if (int.TryParse(Quantity, out int parsedQuantity))

                {

                    asset.Quantity = parsedQuantity;

                }

                else

                {

                    ModelState.AddModelError("Quantity", "Invalid Quantity format.");

                    return View(asset);

                }



                if (decimal.TryParse(PurchasePrice, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal parsedPurchasePrice))

                {

                    asset.PurchasePrice = parsedPurchasePrice;

                }

                else

                {

                    ModelState.AddModelError("PurchasePrice", "Invalid Purchase Price format.");

                    return View(asset);

                }



                if (await _portfolioServices.UpdateAssetAsync(asset))

                {

                    return RedirectToAction("Details", new { id = asset.PortfolioId });

                }

                else

                {

                    ModelState.AddModelError("", "An error occurred while editing the asset. Please try again.");

                }

            }

            catch (Exception ex)

            {

                Debug.WriteLine($"EditAsset POST: General Exception: {ex.Message}");

                ModelState.AddModelError("", "An error occurred while editing the asset. Please try again.");

            }

            return View(asset);

        }



        // GET: Portfolio/DeleteAsset/5 

        public async Task<IActionResult> DeleteAsset(int? id)

        {

            var asset = await _portfolioServices.GetAssetByIdAsync(id);

            if (asset == null)

            {

                return NotFound();

            }

            return View(asset);

        }



        // POST: Portfolio/DeleteAsset/5 

        [HttpPost, ActionName("DeleteAsset")]

        [ValidateAntiForgeryToken]

        public async Task<IActionResult> DeleteAssetConfirmed(int id)

        {

            var asset = await _portfolioServices.GetAssetByIdAsync(id);

            if (asset == null)

            {

                return NotFound();

            }



            var portfolioId = asset.PortfolioId;



            if (await _portfolioServices.DeleteAssetAsync(id))

            {

                return RedirectToAction("Details", "Portfolio", new { id = portfolioId });

            }

            else
            {
                return NotFound();
            }
        }

    }

}