﻿using IPMS_Final.Models;
using IPMS_Final.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace IPMS_Final_MVC.Controllers
{
    public class RiskController : Controller
    {
        private readonly RiskService _riskService;
        public RiskController(RiskService riskService)
        {
            _riskService = riskService;
        }
        public async Task<IActionResult> CalculateRisk()
        {
            return View();
        }
        [HttpPost]

        public async Task<IActionResult> CalculateRisk(int portfolioId)

        {
            if (portfolioId <= 0)
            {
                ViewBag.ErrorMessage = "Portfolio ID not found. Please enter a valid ID.";

                return View();
            }
            else
            {
                var risk = await _riskService.CalculateAndAddRiskAsync(portfolioId);
                if (risk == null)
                {
                    ViewBag.ErrorMessage = $"Portfolio with ID {portfolioId} not found.";
                    return View();
                }
                return RedirectToAction("ViewRiskAnalysis", new { riskId = risk.RiskId });
            }
        }
        public async Task<IActionResult> ViewRiskAnalysis(int riskId)
        {
            var risk = await _riskService.GetRiskByIdAsync(riskId);
            if (risk == null)
            {
                return NotFound();
            }
            ViewData["RiskService"] = _riskService;
            return View(risk);
        }
        public async Task<IActionResult> ViewAllRisks()
        {
            var risks = await _riskService.GetAllRisks();
            return View(risks);
        }
        [HttpPost]
        public async Task<IActionResult> DeleteRisk(int riskId)
        {
            var result = await _riskService.DeleteRiskAsync(riskId);
            if (result)
            {
                return RedirectToAction("ViewAllRisks");
            }
            else
            {
                return NotFound();
            }
        }
    }
}
 


 

