﻿using IPMS_Final.Data;
using IPMS_Final.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IPMS_Final_MVC.Controllers
{
    public class ReportDetailsController : Controller
    {
        private readonly PortfolioDBContext _context;

        public ReportDetailsController(PortfolioDBContext context)
        {
            _context = context;
        }

        // GET: ReportDetails
        public async Task<IActionResult> Index()
        {
            return View(await _context.Reports.ToListAsync()); // Display all reports
        }

        // GET: ReportDetails/Details
        public IActionResult Details()
        {
            return View(); // View to select date for report details
        }

        // POST: ReportDetails/Details
        [HttpPost]
        public async Task<IActionResult> Details(DateTime searchDate)
        {
            var reports = await _context.Reports
                .Where(r => r.generatedDate == DateOnly.FromDateTime(searchDate))
                .ToListAsync();

            return View("DetailsResults", reports); // Display report details for the selected date
        }

        // GET: ReportDetails/ReportDetails/5
        public async Task<IActionResult> ReportDetails(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var report = await _context.Reports.FirstOrDefaultAsync(m => m.reportId == id);
            if (report == null)
            {
                return NotFound();
            }

            return View(report);
        }

        // GET: ReportDetails/Delete/5
        //public async Task<IActionResult> Delete(int? id)
        //{
        //    if (id == null)
        //    {
        //        return NotFound();
        //    }

        //    var report = await _context.Reports.FirstOrDefaultAsync(m => m.reportId == id);
        //    if (report == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(report); // VERY IMPORTANT LINE
        //}

        //// POST: ReportDetails/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> DeleteConfirmed(int id)
        //{
        //    var report = await _context.Reports.FindAsync(id);
        //    if (report == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.Reports.Remove(report);
        //    await _context.SaveChangesAsync();

        //    TempData["SuccessMessage"] = "Report deleted successfully.";
        //    return RedirectToAction(nameof(Index));
        //}
        // GET: Reports/Delete/5
        //public async Task<IActionResult> Delete(int? id)
        //{
        //    if (id == null || _context.Reports == null)
        //    {
        //        return NotFound();
        //    }

        //    var report = await _context.Reports.FirstOrDefaultAsync(m => m.reportId == id);
        //    if (report == null)
        //    {
        //        return NotFound();
        //    }

        //    return View(report);
        //}

        //GET: Reports/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Reports == null)
            {
                return NotFound();
            }

            var report = await _context.Reports.FirstOrDefaultAsync(m => m.reportId == id);
            if (report == null)
            {
                return NotFound();
            }

            return View(report);
        }


        // POST: Reports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Reports == null)
            {
                return Problem("Entity set 'PortfolioDBContext.Reports'  is null.");
            }
            var report = await _context.Reports.FindAsync(id);
            if (report != null)
            {
                _context.Reports.Remove(report);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ReportExists(int id)
        {
            return _context.Reports.Any(e => e.reportId == id);
        }
    }
}