using IPMS_Final.Data;
using IPMS_Final.Repositories;
using IPMS_Final.Services;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60); // Set session timeout
    options.Cookie.HttpOnly = true; // Make the session cookie HTTP-only
    options.Cookie.IsEssential = true; // Make the session cookie essential
});

builder.Services.AddDbContext<PortfolioDBContext>();

builder.Services.AddScoped<ReportService>(); // Add ReportService for DI
builder.Services.AddScoped<RiskService>();
builder.Services.AddScoped<PerformanceServices>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<AssetServices>();//
builder.Services.AddScoped<Portservices>();//
var app = builder.Build();
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// **Add this line to enable session middleware**
app.UseSession();

app.UseAuthorization();

app.MapControllerRoute( // Add the default route here
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();